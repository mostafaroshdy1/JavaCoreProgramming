@FunctionalInterface
public interface StringActions{
  public boolean betterString(String str1,String str2);
}
